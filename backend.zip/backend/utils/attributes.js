const attributes = [
  {
    _id: "63f078f54b86ed26b05281b2",
    type: "attribute",
    extraType: "multiple",
    status: "show",
    title: {
      en: "Color",
    },
    name: {
      en: "Color",
    },
    variants: [
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b3",
        name: {
          en: "Red",
        },
        hexColor: "#FF0000",
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b4",
        name: {
          en: "Green",
        },
        hexColor: "#00FF00",
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b5",
        name: {
          en: "Blue",
        },
        hexColor: "#0000FF",
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b6",
        name: {
          en: "Yellow",
        },
        hexColor: "#FFFF00",
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b7",
        name: {
          en: "Purple",
        },
        hexColor: "#800080",
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b8",
        name: {
          en: "Orange",
        },
        hexColor: "#FFA500",
      },
    ],
    option: "Dropdown",
  },
  {
    _id: "63f078f54b86ed26b05281b6",
    type: "attribute",
    extraType: "multiple",
    status: "show",
    title: {
      en: "Size",
    },
    name: {
      en: "Size",
    },
    variants: [
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b7",
        name: {
          en: "Small",
        },
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b8",
        name: {
          en: "Medium",
        },
      },
      {
        status: "show",
        _id: "63f078f54b86ed26b05281b9",
        name: {
          en: "Large",
        },
      },
    ],
    option: "Radio",
  },
  {
    _id: "63f34946d3639309840ca336",
    type: "extra",
    extraType: "multiple",
    status: "show",
    title: {
      en: "Gift Wrap",
    },
    name: {
      en: "Gift Wrap",
    },
    variants: [
      {
        status: "show",
        _id: "63f34946d3639309840ca337",
        name: {
          en: "Yes",
        },
      },
      {
        status: "show",
        _id: "63f34946d3639309840ca338",
        name: {
          en: "No",
        },
      },
    ],
    option: "Checkbox",
  },
  {
    _id: "63f34983d3639309840ca64a",
    type: "extra",
    extraType: "multiple",
    status: "show",
    title: {
      en: "Package",
    },
    name: {
      en: "Package",
    },
    variants: [
      {
        status: "show",
        _id: "63f34983d3639309840ca64b",
        name: {
          en: "Plastic",
        },
      },
      {
        status: "show",
        _id: "63f34983d3639309840ca64c",
        name: {
          en: "Jar",
        },
      },
      {
        status: "show",
        _id: "63f34983d3639309840ca64d",
        name: {
          en: "Eco Friendly",
        },
      },
    ],
    option: "Checkbox",
  },
];

module.exports = attributes;
